n = int(input("Podaj ilosc wyrazow ciagu: "))
an = 0
for i in range(0, n):
    an = 2 * an + 1
    print(an)