n = int(input("Podaj ilosc wyrazow ciagu: "))
for i in range(0, n):
    print(4+(i*3))